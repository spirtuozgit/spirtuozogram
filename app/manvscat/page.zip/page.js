"use client";
import { useEffect, useState } from "react";
import Link from "next/link";

export default function ManVsCat() {
  const [autoRotate, setAutoRotate] = useState(false);

  useEffect(() => {
    const ring = document.getElementById("ring");
    const handle = document.getElementById("ringHandle");
    const timeEl = document.getElementById("time");
    const left = document.getElementById("chart-left");
    const right = document.getElementById("chart-right");

    let dragging = false;
    let targetAngle = 0;
    let drawAngle = 0;
    let prevPointer = null;
    const ECHO = 0.15;

    const toRad = (deg) => (deg * Math.PI) / 180;
    const norm360 = (a) => ((a % 360) + 360) % 360;

    function shortestDelta(target, current) {
      return (target - current + 540) % 360 - 180;
    }

    function pointerAngle(clientX, clientY) {
      const r = ring.getBoundingClientRect();
      const cx = r.left + r.width / 2;
      const cy = r.top + r.height / 2;
      const dx = clientX - cx;
      const dy = clientY - cy;
      let deg = (Math.atan2(dy, dx) * 180) / Math.PI;
      if (deg < 0) deg += 360;
      return (deg + 90) % 360;
    }

    function placeHandleBy(angleDeg) {
      const size = parseFloat(getComputedStyle(ring).getPropertyValue("width"));
      const r = size / 2 - 2;
      const c = size / 2;
      const rad = toRad(angleDeg - 90);
      handle.style.left = `${c + r * Math.cos(rad)}px`;
      handle.style.top = `${c + r * Math.sin(rad)}px`;
    }

    function updateParallax(angle) {
      const rad = (angle * Math.PI) / 180;
      const depth = 20;

      const cat = document.querySelector(".cat");
      const food = document.querySelector(".food");
      const mouse = document.querySelector(".mouse");
      const clock = document.querySelector(".clock");

      if (cat) cat.style.transform = `translateX(${Math.sin(rad) * depth}px)`;
      if (food) food.style.transform = `translateX(${Math.cos(rad) * depth * 1.2}px)`;
      if (mouse) mouse.style.transform = `translateX(${Math.sin(rad * 1.5) * depth}px)`;
      if (clock) clock.style.transform = `translateY(${Math.cos(rad) * depth}px) scale(1.05)`;
    }

    handle.addEventListener("mousedown", (e) => {
      dragging = true;
      setAutoRotate(false); // отключаем авто при ручном управлении
      prevPointer = pointerAngle(e.clientX, e.clientY);
      e.preventDefault();
    });
    document.addEventListener("mouseup", () => {
      dragging = false;
      prevPointer = null;
    });
    document.addEventListener("mousemove", (e) => {
      if (!dragging) return;
      const cur = pointerAngle(e.clientX, e.clientY);
      const step = shortestDelta(cur, prevPointer);
      targetAngle += step;
      prevPointer = cur;
    });

    function tick() {
      if (autoRotate) targetAngle += 0.3;

      const delta = shortestDelta(targetAngle, drawAngle);
      drawAngle += delta * ECHO;
      const a = norm360(drawAngle);

      placeHandleBy(a);

      const minutes = Math.round((a / 360) * 1440) % 1440;
      let hours = Math.floor(minutes / 60);
      const mins = String(minutes % 60).padStart(2, "0");
      const ampm = hours >= 12 ? "PM" : "AM";
      hours = hours % 12;
      if (hours === 0) hours = 12;
      timeEl.textContent = `${hours}:${mins} ${ampm}`;

      if (left) left.style.transform = `rotate(${a}deg)`;
      if (right) right.style.transform = `rotate(${-a}deg)`;

      updateParallax(drawAngle);
      requestAnimationFrame(tick);
    }

    placeHandleBy(0);
    requestAnimationFrame(tick);
  }, [autoRotate]);

  return (
    <main className="relative flex flex-col items-center justify-center h-screen bg-black text-white overflow-hidden">
      {/* Кнопка назад */}
      <Link
        href="/"
        className="absolute top-4 left-4 px-4 py-2 bg-gray-800 hover:bg-gray-700 rounded-lg shadow-md transition z-20"
      >
        ← Назад
      </Link>

      <h1 className="text-xl mb-6">Синхронизация с котом в течение дня</h1>

      {/* SVG графика */}
      <div className="relative flex gap-0 z-10">
        <object id="chart-left" type="image/svg+xml" data="/svg/Man.svg" className="w-[320px] h-[320px]"></object>
        <object id="chart-right" type="image/svg+xml" data="/svg/Cat.svg" className="w-[320px] h-[320px]"></object>
        <img
          src="/svg/sync.svg"
          alt="sync"
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[60px] pointer-events-none"
        />
      </div>

      {/* Кольцо */}
      <div className="relative w-[220px] h-[220px] z-10" id="ring">
        <div className="absolute inset-0 rounded-full border border-white/60"></div>
        <div
          id="ringHandle"
          className="absolute w-[20px] h-[20px] bg-contain bg-center -translate-x-1/2 -translate-y-1/2"
          style={{ backgroundImage: "url(/svg/handle.svg)" }}
        ></div>
        <div
          className="absolute inset-0 grid place-items-center text-gray-300 select-none pointer-events-none"
          id="time"
        >
          12:00 AM
        </div>

        {/* Автопрокрутка */}
        <div className="absolute -bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1">
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={autoRotate}
              onChange={(e) => setAutoRotate(e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-12 h-6 bg-gray-700 rounded-full peer-checked:bg-green-500 transition"></div>
            <div className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full transition-transform peer-checked:translate-x-6"></div>
          </label>
          <span className="text-xs text-gray-400">Автопрокрутка</span>
        </div>
      </div>

      {/* Фоновые элементы */}
      <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden">
        <img src="/image/image_cat.png" className="cat absolute bottom-0 left-[10%] w-[280px]" />
        <img src="/image/image_mouse.png" className="mouse absolute bottom-[20px] right-[15%] w-[120px]" />
        <img src="/image/image_food.png" className="food absolute top-[40px] right-[10%] w-[220px]" />
        <img src="/image/image_clock.png" className="clock absolute top-[10%] left-[10%] w-[180px]" />
      </div>
    </main>
  );
}
