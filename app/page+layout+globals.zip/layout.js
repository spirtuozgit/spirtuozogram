import "./globals.css";
import { Rubik } from "next/font/google";

/* Делаем переменную --font-rubik, чтобы globals.css мог её подхватить */
const rubik = Rubik({
  subsets: ["latin", "cyrillic"],
  weight: ["400", "500", "700"],
  variable: "--font-rubik",
});

export const metadata = {
  title: "SPIRTUOZOGRAM",
  description: "Минимальный стартовый проект",
};

export default function RootLayout({ children }) {
  return (
    <html lang="ru">
      {/* важно: прокидываем класс с переменной */}
      <body className={rubik.variable}>{children}</body>
    </html>
  );
}
